﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form17 : Form
    {
        public Form17()
        {
            InitializeComponent();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Hide();
            Form16 form16 = new Form16();
            form16.ShowDialog();
            Close();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            pictureBox6.Visible = true;
            panel1.Visible = true;
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            pictureBox6.Visible = false;
            panel1.Visible = false;
        }
    }
}
