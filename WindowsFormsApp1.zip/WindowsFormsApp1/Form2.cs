﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Media;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using static System.Net.WebRequestMethods;
using System.Windows.Forms.VisualStyles;
using System.Reflection.Emit;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Hide();
            Form1 Form1 =new Form1();
            Form1.ShowDialog();
            Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            panel2.Visible= false;
            pictureBox3.Visible= true;
            pictureBox1.Visible= false;
            panel3.Visible= true;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            pictureBox3.Visible = false;
            pictureBox1.Visible = true;
            panel3.Visible = false;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            panel4.Visible = true;
            pictureBox5.Visible = true;
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            panel4.Visible = false;
            pictureBox5.Visible = false;
            textBox1.Clear();
        }

        private void button3_MouseDown(object sender, MouseEventArgs e)
        {
            FileStream load = new FileStream("C:\\Users\\Эльвира\\Desktop\\Учёба\\ТРПО\\Шутки.txt", FileMode.Open);
            StreamReader read = new StreamReader(load);
            string text = read.ReadToEnd();
            string[] words = text.Split(')');
            textBox1.Text = text;
            textBox1.ScrollBars = ScrollBars.Both;
        }

        
    }
}
