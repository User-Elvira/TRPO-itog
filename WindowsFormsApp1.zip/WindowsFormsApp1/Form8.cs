﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class Form8 : Form
    {
        private SqlConnection SqlConnection = null;
        public Form8()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            SqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["BD"].ConnectionString);

            SqlConnection.Open();

            if (SqlConnection.State==ConnectionState.Open)
            {
                MessageBox.Show("Подключение с базой данных установленно");
            }
          
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand command = new SqlCommand(
                $"INSERT INTO [BD](name,opisanie, ingridient,cena) VALUES (@name, @opisanie, @ingridient, @cena)",
                SqlConnection);
            command.Parameters.AddWithValue("name",textBox1.Text);
            command.Parameters.AddWithValue("opisanie", textBox2.Text);
            command.Parameters.AddWithValue("ingridient", textBox3.Text);
            command.Parameters.AddWithValue("cena", textBox4.Text);
            MessageBox.Show(command.ExecuteNonQuery().ToString());
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
        }
    }
    
}
