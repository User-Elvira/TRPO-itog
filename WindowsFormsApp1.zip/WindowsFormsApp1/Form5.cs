﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
            int a = 1;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Hide();
            Form1 form1 = new Form1();
            form1.ShowDialog(); 
            Close();
        }

        public void pictureBox4_Click(object sender, EventArgs e)
        {
            int a=1;
            a++;
            label1.Text = a.ToString();

        }

        public void pictureBox8_Click(object sender, EventArgs e)
        {
            int a = int.Parse(label1.Text);
            a--;
            label1.Text = a.ToString();

        }
    }
}
