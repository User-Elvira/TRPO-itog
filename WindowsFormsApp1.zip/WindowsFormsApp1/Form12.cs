﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form12 : Form
    {
        public Form12()
        {
            InitializeComponent();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            pictureBox4.Visible = false;
            pictureBox5.Visible = true;
            pictureBox3.Visible = false;
            pictureBox1.Visible = false;
            pictureBox7.Visible = true;
            pictureBox2.Visible = true;
            pictureBox8.Visible = true;
            pictureBox6.Visible = false;
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            Hide();
            Form9 form9 = new Form9();
            form9.ShowDialog();
            Close();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            pictureBox4.Visible = true;
            pictureBox5.Visible = false;
            pictureBox3.Visible = true;
            pictureBox1.Visible = true;
            pictureBox7.Visible = false;
            pictureBox2.Visible = false;
            pictureBox8.Visible = false;
            pictureBox6.Visible = true;
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            Hide();
            Form3 form3 = new Form3();
            form3.ShowDialog();
            Close();
        }
    }
}
