﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form15 : Form
    {
        public Form15()
        {
            InitializeComponent();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            int a = 1;
            a++;
            label1.Text = a.ToString();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            int a = int.Parse(label1.Text);
            a--;
            label1.Text = a.ToString();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Hide();
            Form16 form16 = new Form16();
            form16.ShowDialog();
            Close();
        }
    }
}
